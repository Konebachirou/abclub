<?php $__env->startSection('content'); ?>
<div class="rbt-error-area  rbt-section-gap">
        <div class="error-area">
            <div class="container">
                <div class="row justify-content-center text-center">
                    <div class="col-10">
                        <h5 style="font-size: 36px;">Félicitation <?php echo e(Auth::user()->name); ?> ! <br> Bienvenue au sein de la famille African Business Club.</h5>
                        <p>Dans les  les prochaines heures, vous recevrez un email de l'équipe IT contenant votre adresse mail ABC.</p>
                        <a class="rbt-btn btn-gradient icon-hover" href="<?php echo e(route('home_link')); ?>">
                            <span class="btn-text">Acceuil</span>
                            <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('users.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /homepages/42/d770145614/htdocs/abclub/resources/views/users/global/connect_checkout.blade.php ENDPATH**/ ?>