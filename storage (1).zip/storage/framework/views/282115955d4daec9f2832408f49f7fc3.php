<?php if (isset($component)) { $__componentOriginalaa758e6a82983efcbf593f765e026bd9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalaa758e6a82983efcbf593f765e026bd9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => $__env->getContainer()->make(Illuminate\View\Factory::class)->make('mail::message'),'data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('mail::message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <h5> Cher Responsable de pôle,</h5><br>
    J'espère que ce message vous trouve en pleine forme. Je suis ravi(e) de vous informer que nous avons un nouveau membre qui vient de rejoindre notre communauté. <br>
    <?php echo e($user->name); ?> est maintenant officiellement Adherent de notre association. <br>

    En tant que responsable, nous avons prions de prendre les mesures nécessaires pour créer les accès requis afin que <?php echo e($user->name); ?> puisse pleinement profiter de notre plateforme. <br>

    Nous pensons que l'arrivée de <?php echo e($user->name); ?> enrichira notre communauté, et nous encourageons tous les membres à lui réserver un accueil chaleureux. <br>

    Cordialement,<br>
    <?php echo e(config('app.name')); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalaa758e6a82983efcbf593f765e026bd9)): ?>
<?php $attributes = $__attributesOriginalaa758e6a82983efcbf593f765e026bd9; ?>
<?php unset($__attributesOriginalaa758e6a82983efcbf593f765e026bd9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalaa758e6a82983efcbf593f765e026bd9)): ?>
<?php $component = $__componentOriginalaa758e6a82983efcbf593f765e026bd9; ?>
<?php unset($__componentOriginalaa758e6a82983efcbf593f765e026bd9); ?>
<?php endif; ?>
<?php /**PATH /homepages/42/d770145614/htdocs/abclub/resources/views/emails/abclub/connectIT.blade.php ENDPATH**/ ?>