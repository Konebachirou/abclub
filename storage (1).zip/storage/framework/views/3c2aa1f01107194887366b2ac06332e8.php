<div>
    <!-- Start Brand Area  -->
   <div class="rbt-brand-area bg-color-secondary-alt" style="padding-top: 5%; padding-bottom: 5%;">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-12">
                    <div class="section-title text-center mb--40">
                        <h4 class="small-title w-600">Ils nous font confiance</h4>
                    </div>
                </div>
                <div class="col-lg-12">
                    <ul class="brand-list brand-style-1">
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e($partner->website); ?>"><img src="<?php echo e($partner->logoUrl()); ?>" alt="<?php echo e($partner->name); ?>"></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                    </ul>
                </div>
            </div>
        </div>
    </div>  
    <!-- End Brand Area  -->
</div>
<?php /**PATH /homepages/42/d770145614/htdocs/abclub/resources/views/livewire/component/partner-component.blade.php ENDPATH**/ ?>