[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH /homepages/42/d770145614/htdocs/abclub/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/header.blade.php ENDPATH**/ ?>