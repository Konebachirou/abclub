<?php $__env->startSection('titre', 'Entrepreneuriat - African Business Club'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Start CallTo Action Area  -->
    <div class="rbt-call-to-action-area rbt-section-gap bg-gradient-6 rbt-call-to-action-5">
        <div class="wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="rbt-cta-5">
                            <div class="content">
                                <h1 class="title text-center">Candidatez à l'African Next Entrepreneurs</h1>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="shape-images">
                <img src="assets/images/icons/three-shape.png" alt="Shape Images">
            </div>
        </div>
        <!-- End CallTo Action Area  -->


        <div class="checkout_area bg-color-white rbt-section-gap">
            <div class="container">
                <div class="row g-5 checkout-form">
                    <div class="checkout-content-wrapper">
                        <form id="billing-form" action="<?php echo e(route('postuler-store')); ?>" method="POST"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-6 col-12 mb--20">
                                    <label>Nom de votre projet /entreprise</label>
                                    <input name="nom_projet_entreprise" type="text"
                                        placeholder="Nom de votre projet /entreprise">
                                    <?php $__errorArgs = ['nom_projet_entreprise'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 col-12 mb--20">
                                    <label>Choisissez une option de la liste *</label>
                                    <div class="rbt-modern-select bg-transparent height-45">
                                        <select name="Choisissez_option_liste" class="w-100">
                                            <?php $__currentLoopData = $selects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item); ?>"><?php echo e($item); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['Choisissez_option_liste'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-md-6 col-12 mb--20">
                                    <label>Nom de famille </label>
                                    <input name="nom_de_famille" type="text" placeholder="Nom de famille ">
                                    <?php $__errorArgs = ['nom_de_famille'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 col-12 mb--20">
                                    <label>Prénom *</label>
                                    <input name="prenom" type="text" placeholder="Prénom">
                                    <?php $__errorArgs = ['prenom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 col-12 mb--20">
                                    <label>Quel est votre date de naissance ? *</label>
                                    <input name="date_naissance" type="date"
                                        placeholder="Quel est votre date de naissance ?">
                                    <?php $__errorArgs = ['date_naissance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 col-12 mb--20">
                                    <label>Numéro de téléphone *</label>
                                    <input name="numero_telephone" type="text" placeholder="Numéro de téléphone ?">
                                    <?php $__errorArgs = ['numero_telephone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-md-6 col-12 mb--20">
                                    <label>Email</label>
                                    <input name="email" type="email" placeholder="Email">
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-md-6 col-12 mb--20">
                                    <label>Expliquez-nous votre parcours professionnel :</label>
                                    <textarea type="text" name="parcours_professionnel" placeholder="Saisissez votre texte ici"></textarea>
                                    <?php $__errorArgs = ['parcours_professionnel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-md-6 col-12 mb--20">
                                    <label>Code postal *</label>
                                    <input name="code_postal" type="text" placeholder="Code postal *">
                                    <?php $__errorArgs = ['code_postal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 col-12 mb--20">
                                    <label>Date de création de l'entreprise (si celle-ci est créée)*</label>
                                    <input name="date_creation_entreprise" type="date" placeholder="Code postal *">
                                    <?php $__errorArgs = ['date_creation_entreprise'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 col-12 mb--20">
                                    <label>Numéro de SIREN (si votre entreprise est immatriculée en France)</label>
                                    <input name="numero_siren" type="number"
                                        placeholder="Numéro de SIREN (si votre entreprise est immatriculée en France)">
                                    <?php $__errorArgs = ['numero_siren'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 col-12 mb--20">
                                    <label>Nom déposé de la société</label>
                                    <input name="nom_depose_societe" type="number" placeholder="Nom déposé de la société">
                                    <?php $__errorArgs = ['nom_depose_societe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 col-12 mb--20">
                                    <h5>Etes vous associé ?</h5>
                                    <div class="rbt-form-check">
                                        <input class="form-check-input" value="Oui" type="radio"
                                            name="etes_vous_associe" id="rbt-radio-1">
                                        <label class="form-check-label" for="rbt-radio-1"> Oui</label>
                                    </div>
                                    <div class="rbt-form-check">
                                        <input class="form-check-input" value="Non" type="radio"
                                            name="etes_vous_associe" id="rbt-radio-2">
                                        <label class="form-check-label" for="rbt-radio-2"> Non, je ne souhaite pas</label>
                                    </div>
                                    <div class="rbt-form-check">
                                        <input class="form-check-input" value="Pas encore" type="radio"
                                            name="etes_vous_associe" id="rbt-radio-3">
                                        <label class="form-check-label" for="rbt-radio-3"> Pas encore, mais j'y
                                            pense</label>
                                    </div>
                                    <?php $__errorArgs = ['etes_vous_associe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 col-12 mb--20">
                                    <label>Votre activité *</label>
                                    <div class="rbt-modern-select bg-transparent height-45">
                                        <select name="activite" class="w-100">
                                            <option value="Dhaka">Dhaka</option>
                                            <option value="barisal">Barisal</option>
                                            <option value="khulna">Khulna</option>
                                            <option value="comila">Comilla</option>
                                        </select>
                                        <?php $__errorArgs = ['activite'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-md-6 col-12 mb--20">
                                    <label>Décrivez votre activité *</label>
                                    <textarea type="text" name="decrivez_votre_activite" placeholder="Décrivez votre activité *"></textarea>
                                    <?php $__errorArgs = ['decrivez_votre_activite'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>


                                <h5 class="text-center mb--50 mt--10">Votre Business model <br>
                                    Aidez nous a mieux comprendre votre projet au travers de votre Business model</h5>

                                <div class="col-md-6 col-12 mb--20">
                                    <label>Votre segment de clients *</label>
                                    <input type="text" name="segment_clients"
                                        placeholder="Décrivez Votre segment de clients *">
                                    <?php $__errorArgs = ['segment_clients'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 col-12 mb--20">
                                    <label>Relation client envisagée ?</label>
                                    <input type="text" name="relation_client_envisagee"
                                        placeholder="Décrivez Relation client envisagée ?">
                                    <?php $__errorArgs = ['relation_client_envisagee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 col-12 mb--20">
                                    <label>Canaux de distribution *</label>
                                    <input type="text" name="canaux_distribution"
                                        placeholder="Décrivez Canaux de distribution *">
                                    <?php $__errorArgs = ['canaux_distribution'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 col-12 mb--20">
                                    <label>La proposition de valeur (1phrase)</label>
                                    <input type="text" name="proposition_valeur"
                                        placeholder="Décrivez La proposition de valeur (1phrase)">
                                    <?php $__errorArgs = ['proposition_valeur'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 col-12 mb--20">
                                    <label>Activité clé *</label>
                                    <input type="text" name="activite_cle"
                                        placeholder="Décrivez Votre segment de clients *">
                                    <?php $__errorArgs = ['activite_cle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 col-12 mb--20">
                                    <label>Ressources clé *</label>
                                    <input type="text" name="ressources_cle" placeholder="Ressources clé *">
                                    <?php $__errorArgs = ['ressources_cle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 col-12 mb--20">
                                    <label>Partenaires clés *</label>
                                    <input type="text" name="partenaires_cles" placeholder="Partenaires clés *">
                                    <?php $__errorArgs = ['partenaires_cles'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 col-12 mb--20">
                                    <label>Structure de couts *</label>
                                    <input type="text" name="structure_couts" placeholder="Structure de couts *">
                                    <?php $__errorArgs = ['structure_couts'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 col-12 mb--20">
                                    <label>Structure de revenus *</label>
                                    <input type="text" name="structure_revenus" placeholder="Structure de revenus *">
                                    <?php $__errorArgs = ['structure_revenus'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 col-12 mb--20">
                                    <label>CA 2022 *</label>
                                    <input type="number" name="ca_n1" placeholder=" CA 2022 *">
                                    <?php $__errorArgs = ['ca_2022'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 col-12 mb--20">
                                    <label>CA 2023 *</label>
                                    <input type="number" name="ca_n2" placeholder=" CA 2023 *">
                                    <?php $__errorArgs = ['ca_2023'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 col-12 mb--20">
                                    <label>CA 2024 ( Prévisionel) *</label>
                                    <input type="number" name="ca_n3" placeholder=" CA 2024 *">
                                    <?php $__errorArgs = ['ca_2024'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 col-12 mb--20">
                                    <label>CA 2025 ( Prévisionel) *</label>
                                    <input type="number" name="ca_n4" placeholder=" CA 2024 *">
                                    <?php $__errorArgs = ['ca_2025'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 col-12 mb--20">
                                    <label>Effectif 2022 ( Prévisionel) *</label>
                                    <input type="number" name="effectif_n1" placeholder=" Effectif 2022 *">
                                    <?php $__errorArgs = ['effectif_2022'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 col-12 mb--20">
                                    <label>Effectif 2023 ( Prévisionel) *</label>
                                    <input type="number" name="effectif_n2" placeholder=" Effectif 2023 *">
                                    <?php $__errorArgs = ['effectif_2023'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 col-12 mb--20">
                                    <label>Effectif 2024 ( Prévisionel) *</label>
                                    <input type="number" name="effectif_n3" placeholder=" Effectif 2024 *">
                                    <?php $__errorArgs = ['effectif_2024'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 col-12 mb--20">
                                    <label>Effectif 2025 ( Prévisionel) *</label>
                                    <input type="number" name="effectif_n4" placeholder=" Effectif 2025 *">
                                    <?php $__errorArgs = ['effectif_2025'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-md-6 col-12 mb--20">
                                    <label>INFO FI + :</label>
                                    <textarea type="text" name="info_fi" placeholder="Saisissez votre texte ici"></textarea>
                                    <?php $__errorArgs = ['info_fi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 col-12 mb--20">
                                    <label>Quel est votre projet de développement en Afrique ? ou quel est votre impact sur
                                        la diaspora africaine ? </label>
                                    <textarea type="text" name="projet_developpement_afrique" placeholder="Saisissez votre texte ici"></textarea>
                                    <?php $__errorArgs = ['projet_developpement_afrique'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 col-12 mb--20">
                                    <label>Caractère environnemental :</label>
                                    <textarea type="text" name="caractere_environnemental" placeholder="Saisissez votre texte ici"></textarea>
                                    <?php $__errorArgs = ['caractere_environnemental'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 col-12 mb--20">
                                    <label>Caractère innovant :</label>
                                    <textarea type="text" name="caractere_innovant" placeholder="Saisissez votre texte ici"></textarea>
                                    <?php $__errorArgs = ['caractere_innovant'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 col-12 mb--20">
                                    <label>Pourquoi avez vous candidaté à ce concours ?</label>
                                    <textarea type="text" name="motivation_concours" placeholder="Saisissez votre texte ici"></textarea>
                                    <?php $__errorArgs = ['motivation_concours'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-md-6 col-12 mb--20">
                                    <label>Site internet</label>
                                    <input type="text" name="site_internet" placeholder=" Site internet">
                                    <?php $__errorArgs = ['site_internet'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-md-6 col-12 mb--30">
                                    <label>Vous pouvez vous présenter au travers d'une vidéo. N'hésitez pas à nous la
                                        partager !</label>
                                    <input type="file" name="lien_video_presentation" placeholder="Telecharger!">
                                    <?php $__errorArgs = ['lien_video_presentation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-12 mb--20">
                                    <div class="plceholder-button text-center mt--50">
                                        <button class="rbt-btn btn-gradient hover-icon-reverse">
                                            <span class="icon-reverse-wrapper">
                                                <span class="btn-text">Je candidate</span>
                                                <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                                <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                            </span>
                                        </button>
                                    </div>
                                </div>

                            </div>

                        </form>
                    </div>
                </div>
            </div>
            <!-- </div> -->
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('users.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /homepages/42/d770145614/htdocs/abclub/resources/views/users/business/ane_form.blade.php ENDPATH**/ ?>