<div>
    <div>

        <div class="col-lg-12">
            <form action="#">
                <input type="text" placeholder="Que cherchez-vous?" wire:model.live="search">
                <!-- <div class="submit-btn">
                    <a class="rbt-btn btn-gradient btn-md" href="#">Search</a>
                </div> -->
            </form>
        </div>
    </div>

    <div class="rbt-separator-mid">
        <hr class="rbt-separator m-0">
    </div>
    <div class="row g-4 pt--30 pb--60">

        <!-- Start Single Card  -->
        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-lg-3 col-md-4 col-sm-6 col-12">
                <div class="rbt-card variation-01 rbt-hover">
                    <div class="rbt-card-img">
                        <a href="<?php echo e(route('event_details_link', $event->title)); ?>">
                            <img src="<?php echo e($event->illustrationUrl()); ?>" alt="<?php echo e($event->title); ?>">
                        </a>
                    </div>
                    <div class="rbt-card-body">
                        <h5 class="rbt-card-title"><a
                                href="<?php echo e(route('event_details_link', $event->title)); ?>"><?php echo e($event->title); ?></a>
                        </h5>
                        <div class="rbt-review">
                            <div class="rating">
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                            </div>
                            <span class="rating-count"> Evenement</span>
                        </div>
                        <div class="rbt-card-bottom">
                            <div class="rbt-price">
                                <span class="current-price"><?php echo e(date('d M \, Y', strtotime($event->start_date))); ?></span>
                                <span class="current-price"><?php echo e(date('d M \, Y', strtotime($event->start_date))); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php endif; ?>
        <?php if(!is_array($events) && count($events) > 0): ?>
            <?php echo e($events->links()); ?>

        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->

        <!-- End Single Card  -->
    </div>
    <div class="rbt-separator-mid">
        <hr class="rbt-separator m-0">
    </div>
    <div class="row g-4 pt--30 pb--60">
        <!-- Start Single Card  -->
        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-lg-3 col-md-4 col-sm-6 col-12">
                <div class="rbt-card variation-01 rbt-hover">
                    <div class="rbt-card-img">
                        <a href="<?php echo e(route('news_details_link', $report->title)); ?>">
                            <img src="<?php echo e($report->illustrationUrl()); ?>" alt="<?php echo e($report->title); ?>">
                        </a>
                    </div>
                    <div class="rbt-card-body">
                        <h5 class="rbt-card-title"><a
                                href="<?php echo e(route('news_details_link', $report->title)); ?>"><?php echo e($report->title); ?></a>
                        </h5>
                        <div class="rbt-review">
                            <div class="rating">
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                            </div>
                            <span class="rating-count"> News</span>
                        </div>
                        <div class="rbt-card-bottom">
                            <div class="rbt-price">
                                <span class="current-price">
                                    <?php echo e(date('d M \, Y', strtotime($report->created_at))); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php endif; ?>
        <?php if(!is_array($reports) && count($reports) > 0): ?>
            <?php echo e($reports->links()); ?>

        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->


        <!-- End Single Card  -->
    </div>
</div>
<?php /**PATH C:\Users\koneb\Desktop\abclub\resources\views/livewire/component/search-component.blade.php ENDPATH**/ ?>