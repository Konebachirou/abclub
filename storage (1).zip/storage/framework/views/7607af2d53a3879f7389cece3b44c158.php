<?php $__env->startSection('titre', 'Events - African Business Club'); ?>

<?php $__env->startSection('content'); ?>
    <div class="rbt-page-banner-wrapper">
        <!-- Start Banner BG Image  -->
        <div class="rbt-banner-image"></div>
        <!-- End Banner BG Image  -->
        <div class="rbt-banner-content">
            <!-- Start Banner Content Top  -->
            <div class="rbt-banner-content-top">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <!-- Start Breadcrumb Area  -->
                            <ul class="page-list">
                                <li class="rbt-breadcrumb-item"><a href="<?php echo e(route('home_link')); ?>">Accueil</a></li>
                                <li>
                                    <div class="icon-right"><i class="feather-chevron-right"></i></div>
                                </li>
                                <li class="rbt-breadcrumb-item active">Tous les événements</li>
                            </ul>
                            <!-- End Breadcrumb Area  -->

                            <div class=" title-wrapper">
                                <h1 class="title mb--0">Tous les événements</h1>
                            </div>
                            <p class="description">Tous savoir sur les événements organisés par l'African Business Club. </p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Banner Content Top  -->
        </div>
        <!-- End Banner Content Top  -->
        <!-- Start Course Top  -->
        <div class="rbt-course-top-wrapper mt--40">
            <div class="container">
                <div class="row g-5 align-items-center">
                    <div class="col-lg-12 mt--60">
                        <ul class="rbt-portfolio-filter filter-tab-button justify-content-start nav nav-tabs" id="rbt-myTab"
                            role="tablist">
                            <?php if($events->count() != 0): ?>
                                <li class="nav-item" role="presentation">
                                    <button class="active" id="all-tab" data-bs-toggle="tab" data-bs-target="#all"
                                        type="button" role="tab" aria-controls="all" aria-selected="true"><span
                                            class="filter-text">Tous les évènements</span> <span
                                            class="course-number"><?php echo e($events->count()); ?></span></button>
                                </li>
                            <?php endif; ?>
                            <?php if($reseaux->count() != 0): ?>
                                <li class="nav-item" role="presentation">
                                    <button id="featured-tab" data-bs-toggle="tab" data-bs-target="#featured" type="button"
                                        role="tab" aria-controls="featured" aria-selected="false"><span
                                            class="filter-text">Events Réseau</span> <span
                                            class="course-number"><?php echo e($reseaux->count()); ?></span></button>
                                </li>
                            <?php endif; ?>
                            <?php if($amids->count() != 0): ?>
                                <li class="nav-item" role="presentation">
                                    <button id="popular-tab" data-bs-toggle="tab" data-bs-target="#popular" type="button"
                                        role="tab" aria-controls="popular" aria-selected="false"><span
                                            class="filter-text">Events AMID</span> <span
                                            class="course-number"><?php echo e($amids->count()); ?></span></button>
                                </li>
                            <?php endif; ?>
                            <?php if($nmss->count() != 0): ?>
                                <li class="nav-item" role="presentation">
                                    <button id="trending-tab" data-bs-toggle="tab" data-bs-target="#trending" type="button"
                                        role="tab" aria-controls="trending" aria-selected="false"><span
                                            class="filter-text">Events Meet & Share</span> <span
                                            class="course-number"><?php echo e($nmss->count()); ?></span></button>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </div>

                </div>
            </div>
        </div>
        <!-- End Course Top  -->
    </div>
    </div>

    <div class="rbt-section-overlayping-top rbt-section-gapBottom">
        <div class="container">
            <!-- Start Card Area -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="tab-content" id="rbt-myTabContent">
                        <div class="tab-pane fade show active" id="all" role="tabpanel" aria-labelledby="all-tab">
                            <div class="row g-5">
                                <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <!-- Start Single Event  -->
                                    <div class="col-lg-6 col-md-6 col-12">
                                        <div class="rbt-card card-list-2 event-list-card variation-01 rbt-hover">
                                            <div class="rbt-card-img">
                                                <a href="<?php echo e(route('event_details_link', $event->title)); ?>">
                                                    <?php if($event->illustration != ''): ?>
                                                        <img src="<?php echo e($event->illustrationUrl()); ?>" alt="Card image">
                                                    <?php else: ?>
                                                        <img src="<?php echo e(asset('assets/images/course/course-01.jpg')); ?>"
                                                            alt="Card image">
                                                    <?php endif; ?>

                                                </a>
                                            </div>
                                            <div class="rbt-card-body">
                                                <ul class="rbt-meta">
                                                    <li><i class="feather-map-pin"></i><?php echo $event->lieu; ?></li><br>
                                                    <li><span><i
                                                                class="feather-calendar"></i><?php echo e(date('d M \, Y', strtotime($event->start_date))); ?></span>
                                                        <span style="padding-left: 10px;"><i
                                                                class="feather-clock"></i><?php echo e(date('H:i ', strtotime($event->start_times))); ?>

                                                            - <?php echo e(date('H:i ', strtotime($event->end_times))); ?>

                                                    </li></span>
                                                </ul>
                                                <h4 class="rbt-card-title"><a
                                                        href="<?php echo e(route('event_details_link', $event->title)); ?>"><?php echo $event->title; ?></a>
                                                </h4>
                                                <div class="read-more-btn">
                                                    <a class="rbt-btn btn-border hover-icon-reverse btn-sm radius-round"
                                                        href="<?php echo e(route('event_details_link', $event->title)); ?>">
                                                        <span class="icon-reverse-wrapper">
                                                            <span class="btn-text">Voir Plus</span>
                                                            <span class="btn-icon"><i
                                                                    class="feather-arrow-right"></i></span>
                                                            <span class="btn-icon"><i
                                                                    class="feather-arrow-right"></i></span>
                                                        </span>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Event  -->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </div>
                        <div class="tab-pane fade" id="featured" role="tabpanel" aria-labelledby="featured-tab">
                            <div class="row g-5">
                                <?php $__currentLoopData = $reseaux; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reseau): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <!-- Start Single Event  -->
                                    <div class="col-lg-6 col-md-6 col-12">
                                        <div class="rbt-card card-list-2 event-list-card variation-01 rbt-hover">
                                            <div class="rbt-card-img">
                                                <a href="<?php echo e(route('event_details_link', $reseau->title)); ?>">
                                                    <img src="<?php echo e($reseau->illustrationUrl()); ?>"
                                                        alt="<?php echo e($reseau->title); ?>">
                                                </a>
                                            </div>
                                            <div class="rbt-card-body">
                                                <ul class="rbt-meta">
                                                    <li><i class="feather-map-pin"></i><?php echo $reseau->lieu; ?></li><br>
                                                    <li><span><i
                                                                class="feather-calendar"></i><?php echo e(date('d M \, Y', strtotime($reseau->start_date))); ?></span>
                                                        <span style="padding-left: 10px;"><i
                                                                class="feather-clock"></i><?php echo e(date('H:i ', strtotime($event->start_times))); ?>

                                                            - <?php echo e(date('H:i ', strtotime($event->end_times))); ?>

                                                    </li>
                                                    </span>
                                                </ul>
                                                <h4 class="rbt-card-title"><a
                                                        href="<?php echo e(route('event_details_link', $reseau->title)); ?>"><?php echo e($reseau->title); ?></a>
                                                </h4>
                                                <div class="read-more-btn">
                                                    <a class="rbt-btn btn-border hover-icon-reverse btn-sm radius-round"
                                                        href="<?php echo e(route('event_details_link', $event->title)); ?>">
                                                        <span class="icon-reverse-wrapper">
                                                            <span class="btn-text">Get Ticket</span>
                                                            <span class="btn-icon"><i
                                                                    class="feather-arrow-right"></i></span>
                                                            <span class="btn-icon"><i
                                                                    class="feather-arrow-right"></i></span>
                                                        </span>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Event  -->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="popular" role="tabpanel" aria-labelledby="popular-tab">
                            <div class="row g-5">
                                <?php $__currentLoopData = $amids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <!-- Start Single Event  -->
                                    <div class="col-lg-6 col-md-6 col-12">
                                        <div class="rbt-card card-list-2 event-list-card variation-01 rbt-hover">
                                            <div class="rbt-card-img">
                                                <a href="<?php echo e(route('event_details_link', $amid->title)); ?>">
                                                    <img src="<?php echo e($amid->illustrationUrl()); ?>" alt="Card image">
                                                </a>
                                            </div>
                                            <div class="rbt-card-body">
                                                <ul class="rbt-meta">
                                                    <li><i class="feather-map-pin"></i><?php echo $amid->lieu; ?></li><br>
                                                    <li><span><i
                                                                class="feather-calendar"></i><?php echo e(date('d M \, Y', strtotime($amid->start_date))); ?></span>
                                                        <span style="padding-left: 10px;"><i
                                                                class="feather-clock"></i><?php echo e(date('H:i ', strtotime($event->start_times))); ?>

                                                            - <?php echo e(date('H:i ', strtotime($event->end_times))); ?>

                                                    </li></span>
                                                </ul>
                                                <h4 class="rbt-card-title"><a
                                                        href="<?php echo e(route('event_details_link', $amid->title)); ?>"><?php echo e($amid->title); ?></a>
                                                </h4>
                                                <div class="read-more-btn">
                                                    <a class="rbt-btn btn-border hover-icon-reverse btn-sm radius-round"
                                                        href="<?php echo e(route('event_details_link', $event->title)); ?>">
                                                        <span class="icon-reverse-wrapper">
                                                            <span class="btn-text">Get Ticket</span>
                                                            <span class="btn-icon"><i
                                                                    class="feather-arrow-right"></i></span>
                                                            <span class="btn-icon"><i
                                                                    class="feather-arrow-right"></i></span>
                                                        </span>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Event  -->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </div>
                        <div class="tab-pane fade" id="trending" role="tabpanel" aria-labelledby="trending-tab">
                            <div class="row g-5">
                                <?php $__currentLoopData = $nmss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <!-- Start Single Event  -->
                                    <div class="col-lg-6 col-md-6 col-12">
                                        <div class="rbt-card card-list-2 event-list-card variation-01 rbt-hover">
                                            <div class="rbt-card-img">
                                                <a href="<?php echo e(route('event_details_link', $nms->title)); ?>">
                                                    <img src="<?php echo e($nms->illustrationUrl()); ?>" alt="Card image">
                                                </a>
                                            </div>
                                            <div class="rbt-card-body">
                                                <ul class="rbt-meta">
                                                    <li><i class="feather-map-pin"></i><?php echo $nms->lieu; ?></li><br>
                                                    <li><span><i
                                                                class="feather-calendar"></i><?php echo e(date('d M \, Y', strtotime($nms->start_date))); ?></span>
                                                        <span style="padding-left: 10px;"><i
                                                                class="feather-clock"></i><?php echo e(date('H:i ', strtotime($event->start_times))); ?>

                                                            - <?php echo e(date('H:i ', strtotime($event->end_times))); ?>

                                                    </li></span>
                                                </ul>
                                                <h4 class="rbt-card-title"><a
                                                        href="<?php echo e(route('event_details_link', $nms->title)); ?>"><?php echo e($nms->title); ?></a>
                                                </h4>
                                                <div class="read-more-btn">
                                                    <a class="rbt-btn btn-border hover-icon-reverse btn-sm radius-round"
                                                        href="<?php echo e(route('event_details_link', $event->title)); ?>">
                                                        <span class="icon-reverse-wrapper">
                                                            <span class="btn-text">Get Ticket</span>
                                                            <span class="btn-icon"><i
                                                                    class="feather-arrow-right"></i></span>
                                                            <span class="btn-icon"><i
                                                                    class="feather-arrow-right"></i></span>
                                                        </span>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Event  -->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /homepages/42/d770145614/htdocs/abclub/resources/views/users/events/event.blade.php ENDPATH**/ ?>