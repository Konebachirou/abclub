<?php $__env->startSection('content'); ?>
    <div class="rbt-overlay-page-wrapper">
        <div class="breadcrumb-image-container breadcrumb-style-max-width">
            <!-- <div class="breadcrumb-image-wrapper">
                 <img src="<?php echo e($new->illustrationUrl()); ?>" alt="Education Images"> 
            </div> -->
            <div class="breadcrumb-content-top text-center">
                <ul class="meta-list justify-content-center mb--10">
                    <li class="list-item">
                        <!-- <div class="author-thumbnail">
                                        <img src="<?php echo e(asset('assets/images/testimonial/client-06.png')); ?>" alt="blog-image">
                                    </div> -->
                        <div class="author-info">
                            <p>Publier le</p>
                        </div>
                    </li>
                    <li class="list-item">
                        <i class="feather-clock"></i>
                        <span><?php echo e(date('d M Y', strtotime($new->created_at))); ?></span>
                    </li>
                </ul>
                <h3 class="title"><?php echo e($new->title); ?></h3>
                <!-- <p>Ten Advices That You Must Listen Before Studying Education.</p> -->
            </div>
        </div>

        <div class="rbt-blog-details-area rbt-section-gapBottom breadcrumb-style-max-width">
            <div class="blog-content-wrapper rbt-article-content-wrapper">
                <div class="content">
                    <div class="post-thumbnail mb--30 position-relative wp-block-image alignwide">
                        <figure>
                            <?php if($new->illustration != ""): ?>
                                <img  src="<?php echo e(Storage::url($new->illustration)); ?>" alt="<?php echo e($new->title); ?>">
                            <?php else: ?>
                                <img src="<?php echo e(asset('assets/images/blog/blog-single-03.png')); ?>" alt="<?php echo e($new->title); ?>">
                            <?php endif; ?>
                            <figcaption class="w-500 m-5"><?php echo $new->caption; ?></figcaption>
                        </figure>
                    </div>
                    <p><?php echo $new->description; ?></p>
                    <div class="rbt-gallery-area" style="margin-top: 5%; margin-bottom: 3%;">
                        <div class="row g-0 parent-gallery-container"
                            style="display: flex; justify-content: center; align-items: center;">
                            <?php if($album != null): ?>
                            <?php for($i = 0; $i < count($album) ; $i++ ): ?> 
                                <a href="<?php echo e(Storage::url($album[$i])); ?>" class="child-gallery-single col-lg-3 col-md-4 col-sm-6 col-6 ">
                                    <div class="rbt-gallery">
                                        <img class="w-100" src="<?php echo e(Storage::url($album[$i])); ?>" alt="Gallery Images">
                                    </div>
                                </a>
                                <?php endfor; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <!-- Social Share Block  -->
                    <!-- <div class="social-share-block">
                        <div class="post-like">
                            <a href="#"><i class="feather feather-thumbs-up"></i><span>2.2k Like</span></a>
                        </div>
                        <ul class="social-icon social-default transparent-with-border">
                            <li><a href="https://www.facebook.com/">
                                    <i class="feather-facebook"></i>
                                </a>
                            </li>
                            <li><a href="https://www.twitter.com">
                                    <i class="feather-twitter"></i>
                                </a>
                            </li>
                            <li><a href="https://www.instagram.com/">
                                    <i class="feather-instagram"></i>
                                </a>
                            </li>
                            <li><a href="https://www.linkdin.com/">
                                    <i class="feather-linkedin"></i>
                                </a>
                            </li>
                        </ul>
                    </div> -->

                </div>
                <div class="rbt-comment-area">
                    <h4 class="title"><?php echo e($new->comments->count()); ?> comments</h4>
                    <ul class="comment-list">
                        <!-- Start Single Comment  -->
                        <?php $__currentLoopData = $new->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="comment">
                                <div class="comment-body">
                                    <div class="single-comment">
                                        <div class="comment-img">
                                            <img src="<?php echo e(asset('assets/images/testimonial/avatar.png')); ?>"
                                                alt="Author Images">
                                        </div>
                                        <div class="comment-inner">
                                            <h6 class="commenter">
                                                <a href="#"><?php echo e($comment->name); ?></a>
                                            </h6>
                                            <div class="comment-meta">
                                                <div class="time-spent">
                                                    <?php echo e(date('d M Y', strtotime($comment->created_at))); ?> à
                                                    <?php echo e(date('h:m ', strtotime($comment->created_at))); ?> </div>
                                                <div class="reply-edit">
                                                    <div class="reply">
                                                        <a class="comment-reply-link" href="#form-comment"
                                                            onclick="document.getElementById('parent_id').value = <?php echo e($comment->id); ?>">Répondre</a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="comment-text">
                                                <p class="b2"><?php echo e($comment->content); ?> </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <ul class="children">
                                    <?php $__empty_1 = true; $__currentLoopData = $comment->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $replie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <!-- Start Single Comment  -->
                                        <li class="comment">
                                            <div class="comment-body">
                                                <div class="single-comment">
                                                    <div class="comment-img">
                                                        <img src="<?php echo e(asset('assets/images/testimonial/avatar.png')); ?>"
                                                            alt="Author Images">
                                                    </div>
                                                    <div class="comment-inner">
                                                        <h6 class="commenter">
                                                            <a href="#">John Due</a>
                                                        </h6>
                                                        <div class="comment-meta">
                                                            <div class="time-spent">Nov 23, 2018 at 12:23 pm
                                                            </div>
                                                            <div class="reply-edit">
                                                                <div class="reply">
                                                                    <a class="comment-reply-link" href="#form-comment"
                                                                        onclick="document.getElementById('parent_id').value = <?php echo e($comment->id); ?>">Reply</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="comment-text">
                                                            <p class="b2"><?php echo e($replie->content); ?></p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>

                                        <!-- End Single Comment  -->
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <?php endif; ?>
                                </ul>
                            </li>
                            <!-- End Single Comment  -->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <div class="rbt-comment-area">
                        <form action="<?php echo e(route('comments-store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="comment-respond" id="form-comment">
                                <h4 class="title">Poster un commentaire</h4>

                                <p class="comment-notes"><span id="email-notes">Votre adresse email ne sera pas publiée.
                                    </span> Les champs requis sont indiqués <span class="required">*</span></p>
                                <div class="row row--10">
                                    <div class="col-lg-6 col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="name">Nom *</label>
                                            <input type="hidden" name="report_id" value="<?php echo e($new->id); ?>">
                                            <input type="hidden" name="parent_id" id="parent_id">
                                            <input id="name" type="text" name="name">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="bl-email">Email *</label>
                                            <input id="bl-email" type="email" name="email">
                                        </div>
                                    </div>

                                    <div class="col-12">
                                        <div class="form-group">
                                            <label for="content">message *</label>
                                            <textarea id="content" name="content" name="content"></textarea>
                                        </div>
                                    </div>

                                    <button type="submit" class="rbt-btn btn-gradient icon-hover radius-round btn-md">
                                        <span class="btn-text">Envoyer</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

            </div>
            <div class="related-post pt--60">
                <div class="section-title text-center mb--40">
                    <span class="subtitle bg-primary-opacity">Post récent</span>
                    <h4 class="title">Post récent</h4>
                </div>

                <!-- Start Single Card  -->
                <?php $__currentLoopData = $similars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $similar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="rbt-card card-list variation-02 rbt-hover mt--30">
                        <div class="rbt-card-img">
                            <a href="<?php echo e(route('news_details_link', $similar->title)); ?>">
                                <img src="<?php echo e($similar->illustrationUrl()); ?>" alt="Card image"> </a>
                        </div>
                        <div class="rbt-card-body">
                            <h5 class="rbt-card-title"><a
                                    href="<?php echo e(route('news_details_link', $similar->title)); ?>"><?php echo e($similar->title); ?></a>
                            </h5>
                            <div class="rbt-card-bottom">
                                <a class="transparent-button"
                                    href="<?php echo e(route('news_details_link', $similar->title)); ?>">Lire
                                    Article<i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg">
                                            <g stroke="#27374D" fill="none" fill-rule="evenodd">
                                                <path d="M10.614 0l5.629 5.629-5.63 5.629" />
                                                <path stroke-linecap="square" d="M.663 5.572h14.594" />
                                            </g>
                                        </svg></i></a>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Card  -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\koneb\Desktop\abclub\resources\views/users/news/news_detail.blade.php ENDPATH**/ ?>