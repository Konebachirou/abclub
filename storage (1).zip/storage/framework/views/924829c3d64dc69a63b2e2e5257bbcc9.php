<div
    <?php echo e($attributes
            ->merge([
                'id' => $getId(),
            ], escape: false)
            ->merge($getExtraAttributes(), escape: false)); ?>

>
    <?php echo e($getChildComponentContainer()); ?>

</div>
<?php /**PATH /homepages/42/d770145614/htdocs/abclub/vendor/filament/forms/src/../resources/views/components/grid.blade.php ENDPATH**/ ?>