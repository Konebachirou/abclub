<?php $__env->startSection('content'); ?>
    <div class="rbt-elements-area bg-color-white rbt-section-gap">
        <div class="container">
            <div class="row gy-5 row--30">
                <div class="col-lg-6  offset-md-3">
                    <div class="rbt-contact-form contact-form-style-1 max-width-auto">
                        <h3 class="title">Connexion</h3>
                        <form class="max-width-auto" method="POST" action="<?php echo e(route('authentification')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <input name="email" type="email" />
                                <label>Email *</label>
                                <span class="focus-border"></span>
                                <?php if($errors->has('email')): ?>
                                    <span class="#"><?php echo e($errors->first('email')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <input name="password" type="password">
                                <label>Mot de passe *</label>
                                <span class="focus-border"></span>
                                <?php if($errors->has('password')): ?>
                                    <span class="#"><?php echo e($errors->first('password')); ?></span>
                                <?php endif; ?>
                            </div>

                            <div class="row mb--30">
                                <div class="col-lg-6">
                                    <!-- <div class="rbt-checkbox">
                                        <input type="checkbox" id="rememberme" name="rememberme">
                                        <label for="rememberme">Resté connecter</label>
                                    </div> -->
                                </div>
                                <div class="col-lg-6">
                                    <div class="rbt-lost-password text-end">
                                        <a class="rbt-btn-link" href="<?php echo e(route('forgotPassword_link')); ?>">Mot de passe
                                            oublié?</a>
                                    </div>
                                </div>
                            </div>

                            <div class="form-submit-group">
                                <button type="submit" class="rbt-btn btn-md btn-gradient hover-icon-reverse w-100">
                                    <span class="icon-reverse-wrapper">
                                        <span class="btn-text">Se connecter</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    </span>
                                </button>
                            </div>
                        </form>
                        <p class="mt-5">Je n'ai pas de Compte, Je<a href="<?php echo e(route('register_link')); ?>" > crée mon compte</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /homepages/42/d770145614/htdocs/abclub/resources/views/users/auth/login.blade.php ENDPATH**/ ?>