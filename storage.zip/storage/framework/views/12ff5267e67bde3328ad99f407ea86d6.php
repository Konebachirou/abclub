<?php $__env->startSection('titre', 'News - African Business Club'); ?>

<?php $__env->startSection('content'); ?>
<div class="rbt-page-banner-wrapper">
    <!-- Start Banner BG Image  -->
    <div class="rbt-banner-image"></div>
    <!-- End Banner BG Image  -->
    <div class="rbt-banner-content">
        <!-- Start Banner Content Top  -->
        <div class="rbt-banner-content-top">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <!-- Start Breadcrumb Area  -->
                        <ul class="page-list">
                            <li class="rbt-breadcrumb-item"><a href="<?php echo e(route('home_link')); ?>">Accueil</a></li>
                            <li>
                                <div class="icon-right"><i class="feather-chevron-right"></i></div>
                            </li>
                            <li class="rbt-breadcrumb-item active">Actualités</li>
                        </ul>
                        <!-- End Breadcrumb Area  -->

                        <div class=" title-wrapper">
                            <h1 class="title mb--0">ABC Actualités</h1>
                        </div>
                        <p class="description">Tous savoir sur l'actualité de l'African Business Club. </p>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Banner Content Top  -->
    </div>
    <!-- End Banner Content Top  -->
    <!-- Start Course Top  -->
    <div class="rbt-course-top-wrapper mt--40">
        <div class="container">
            <div class="row g-5 align-items-center">
                <div class="col-lg-12 mt--60">
                    <ul class="rbt-portfolio-filter filter-tab-button justify-content-start nav nav-tabs" id="rbt-myTab" role="tablist">
                        <?php if($reports->count() != 0): ?>
                        <li class="nav-item" role="presentation">
                            <button class="active" id="all-tab" data-bs-toggle="tab" data-bs-target="#all" type="button" role="tab" aria-controls="all" aria-selected="true"><span class="filter-text">Toutes les News</span> <span class="course-number"><?php echo e($reports->count()); ?></span></button>
                        </li>
                        <?php endif; ?>
                        <?php if($reseaux->count() != 0): ?>
                        <li class="nav-item" role="presentation">
                            <button id="featured-tab" data-bs-toggle="tab" data-bs-target="#featured" type="button" role="tab" aria-controls="featured" aria-selected="false"><span class="filter-text">News Réseau</span> <span class="course-number"><?php echo e($reseaux->count()); ?></span></button>
                        </li>
                        <?php endif; ?>
                        <?php if($amids->count() != 0): ?>
                        <li class="nav-item" role="presentation">
                            <button id="popular-tab" data-bs-toggle="tab" data-bs-target="#popular" type="button" role="tab" aria-controls="popular" aria-selected="false"><span class="filter-text">News AMID</span> <span class="course-number"><?php echo e($amids->count()); ?></span></button>
                        </li>
                        <?php endif; ?>
                        <?php if($nmss->count() != 0): ?>
                        <li class="nav-item" role="presentation">
                            <button id="trending-tab" data-bs-toggle="tab" data-bs-target="#trending" type="button" role="tab" aria-controls="trending" aria-selected="false"><span class="filter-text">News Meet & Share</span> <span class="course-number"><?php echo e($nmss->count()); ?></span></button>
                        </li>
                        <?php endif; ?>
                    </ul>
                </div>

            </div>
        </div>
    </div>
    <!-- End Course Top  -->
</div>
</div>

<div class="rbt-section-overlayping-top rbt-section-gapBottom">
    <div class="container">
        <!-- Start Card Area -->
        <div class="row">
            <div class="col-lg-12">
                <div class="tab-content" id="rbt-myTabContent">
                    <div class="tab-pane fade show active" id="all" role="tabpanel" aria-labelledby="all-tab">
                        <div class="row g-5">
                            <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <!-- Start Single Card  -->
                            <div class="col-lg-6 col-md-6 col-12">
                                <div class="rbt-blog-grid rbt-card variation-02 rbt-hover">
                                    <div class="rbt-card-img">
                                        <a href="<?php echo e(route('news_details_link', $report->title)); ?>">
                                            <img src="<?php echo e($report->illustrationUrl()); ?>" alt="Card image"> </a>
                                    </div>
                                    <div class="rbt-card-body">
                                        <h5 class="rbt-card-title elipses2"><a href="<?php echo e(route('news_details_link', $report->title)); ?>"><?php echo e($report->title); ?></a>
                                        </h5>
                                        <ul class="blog-meta">

                                            <li><i class="feather-clock"></i>
                                                <?php echo e(date('d M \, Y', strtotime($report->created_at))); ?>

                                            </li>
                                        </ul>
                                        <div class="description mt--30" style="display: -webkit-box;
        -webkit-line-clamp: 3;
        -webkit-box-orient: vertical;
        overflow: hidden;"><?php echo $report->description; ?></div>
                                        <!-- <p class="rbt-card-text elipses4"><?php echo Str::limit($report->description, 120); ?></p> -->
                                        <div class="rbt-card-bottom mt-3">
                                            <a class="transparent-button" href="<?php echo e(route('news_details_link', $report->title)); ?>">Lire
                                                Plus<i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg">
                                                        <g stroke="#27374D" fill="none" fill-rule="evenodd">
                                                            <path d="M10.614 0l5.629 5.629-5.63 5.629" />
                                                            <path stroke-linecap="square" d="M.663 5.572h14.594" />
                                                        </g>
                                                    </svg></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Card  -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>
                    <div class="tab-pane fade" id="featured" role="tabpanel" aria-labelledby="featured-tab">
                        <div class="row g-5">
                            <?php $__currentLoopData = $reseaux; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reseau): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <!-- Start Single Card  -->
                            <div class="col-lg-6 col-md-6 col-12">
                                <div class="rbt-blog-grid rbt-card variation-02 rbt-hover">
                                    <div class="rbt-card-img">
                                        <a href="<?php echo e(route('news_details_link', $reseau->title)); ?>">
                                            <img src="<?php echo e($reseau->illustrationUrl()); ?>" alt="Card image"> </a>
                                    </div>
                                    <div class="rbt-card-body">
                                        <h5 class="rbt-card-title elipses2"><a href="<?php echo e(route('news_details_link', $reseau->title)); ?>"><?php echo e($reseau->title); ?></a>
                                        </h5>
                                        <ul class="blog-meta">

                                            <li><i class="feather-clock"></i>
                                                <?php echo e(date('d M \, Y', strtotime($reseau->created_at))); ?>

                                            </li>
                                        </ul>
                                        <div class="description mt--30" style="display: -webkit-box;
        -webkit-line-clamp: 3;
        -webkit-box-orient: vertical;
        overflow: hidden;"><?php echo $reseau->description; ?></div>
                                        <!-- <p class="rbt-card-text elipses4"><?php echo $reseau->description; ?></p> -->
                                        <div class="rbt-card-bottom mt-3">
                                            <a class="transparent-button" href="<?php echo e(route('news_details_link', $reseau->title)); ?>">Lire
                                                Plus<i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg">
                                                        <g stroke="#27374D" fill="none" fill-rule="evenodd">
                                                            <path d="M10.614 0l5.629 5.629-5.63 5.629" />
                                                            <path stroke-linecap="square" d="M.663 5.572h14.594" />
                                                        </g>
                                                    </svg></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Card  -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="popular" role="tabpanel" aria-labelledby="popular-tab">
                        <div class="row g-5">
                            <?php $__currentLoopData = $amids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <!-- Start Single Card  -->
                            <div class="col-lg-6 col-md-6 col-12">
                                <div class="rbt-blog-grid rbt-card variation-02 rbt-hover">
                                    <div class="rbt-card-img">
                                        <a href="<?php echo e(route('news_details_link', $amid->title)); ?>">
                                            <img src="<?php echo e($amid->illustrationUrl()); ?>" alt="Card image"> </a>
                                    </div>
                                    <div class="rbt-card-body">
                                        <h5 class="rbt-card-title elipses2"><a href="<?php echo e(route('news_details_link', $amid->title)); ?>"><?php echo e($amid->title); ?></a>
                                        </h5>
                                        <ul class="blog-meta">

                                            <li><i class="feather-clock"></i>
                                                <?php echo e(date('d M \, Y', strtotime($amid->created_at))); ?>

                                            </li>
                                        </ul>
                                        <div class="description mt--30" style="display: -webkit-box;
        -webkit-line-clamp: 3;
        -webkit-box-orient: vertical;
        overflow: hidden;"><?php echo $amid->description; ?></div>
                                        <!-- <p class="rbt-card-text elipses4"><?php echo $amid->description; ?></p> -->
                                        <div class="rbt-card-bottom">
                                            <a class="transparent-button" href="<?php echo e(route('news_details_link', $amid->title)); ?>">Learn
                                                More<i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg">
                                                        <g stroke="#27374D" fill="none" fill-rule="evenodd">
                                                            <path d="M10.614 0l5.629 5.629-5.63 5.629" />
                                                            <path stroke-linecap="square" d="M.663 5.572h14.594" />
                                                        </g>
                                                    </svg></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Card  -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>
                    <div class="tab-pane fade" id="trending" role="tabpanel" aria-labelledby="trending-tab">
                        <div class="row g-5">
                            <?php $__currentLoopData = $nmss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <!-- Start Single Card  -->
                            <div class="col-lg-6 col-md-6 col-12">
                                <div class="rbt-blog-grid rbt-card variation-02 rbt-hover">
                                    <div class="rbt-card-img">
                                        <a href="<?php echo e(route('news_details_link', $nms->title)); ?>">
                                            <img src="<?php echo e($nms->illustrationUrl()); ?>" alt="Card image"> </a>
                                    </div>
                                    <div class="rbt-card-body">
                                        <h5 class="rbt-card-title elipses2"><a href="<?php echo e(route('news_details_link', $nms->title)); ?>"><?php echo e($nms->title); ?></a>
                                        </h5>
                                        <ul class="blog-meta">
                                            <!-- -->
                                            <li><i class="feather-clock"></i>
                                                <?php echo e(date('d M \, Y', strtotime($nmss->created_at))); ?>

                                            </li>
                                            <!-- <li><i class="feather-watch"></i> 1 min read</li> -->
                                        </ul>
                                        <div class="description mt--30" style="display: -webkit-box;
        -webkit-line-clamp: 3;
        -webkit-box-orient: vertical;
        overflow: hidden;"><?php echo $nms->description; ?></div>
                                        <!-- <p class="rbt-card-text elipses4"><?php echo $nms->description; ?></p> -->
                                        <div class="rbt-card-bottom">
                                            <a class="transparent-button" href="<?php echo e(route('news_details_link', $nms->title)); ?>">Learn
                                                More<i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg">
                                                        <g stroke="#27374D" fill="none" fill-rule="evenodd">
                                                            <path d="M10.614 0l5.629 5.629-5.63 5.629" />
                                                            <path stroke-linecap="square" d="M.663 5.572h14.594" />
                                                        </g>
                                                    </svg></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Card  -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('users.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\koneb\Desktop\abclub\resources\views/users/news/news.blade.php ENDPATH**/ ?>