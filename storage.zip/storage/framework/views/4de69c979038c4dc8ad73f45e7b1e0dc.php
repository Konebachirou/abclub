<div>
    <div class="scroll-animation-wrapper no-overlay mt--50">
        <div class="scroll-animation scroll-right-left">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!-- Start Single Testimonial  -->
                <div class="single-column-20 bg-theme-gradient-odd">
                    <div class="rbt-testimonial-box style-2">
                        <div class="inner">
                            <div class="icons">
                                <img src="<?php echo e($partner->logoUrl()); ?>" alt="<?php echo e($partner->name); ?>">
                            </div>
                            <div class="description">
                                <p class="subtitle-3"><?php echo e($partner->description); ?>.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Single Testimonial  -->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->


        </div>
    </div>
</div>
<?php /**PATH C:\Users\koneb\Desktop\abclub\resources\views/livewire/component/amid-partner-component.blade.php ENDPATH**/ ?>