 <!-- JS
============================================ -->
 <!-- Modernizer JS -->
 <script src="<?php echo e(asset('assets/js/vendor/modernizr.min.js')); ?>"></script>
 <!-- jQuery JS -->
 <script src="<?php echo e(asset('assets/js/vendor/jquery.js')); ?>"></script>
 <!-- Bootstrap JS -->
 <script src="<?php echo e(asset('assets/js/vendor/bootstrap.min.js')); ?>"></script>
 <!-- sal.js -->
 <script src="<?php echo e(asset('assets/js/vendor/sal.js')); ?>"></script>
 <script src="<?php echo e(asset('assets/js/vendor/swiper.js')); ?>"></script>
 <script src="<?php echo e(asset('assets/js/vendor/magnify.min.js')); ?>"></script>
 <script src="<?php echo e(asset('assets/js/vendor/jquery-appear.js')); ?>"></script>
 <script src="<?php echo e(asset('assets/js/vendor/odometer.js')); ?>"></script>
 <script src="<?php echo e(asset('assets/js/vendor/backtotop.js')); ?>"></script>
 <script src="<?php echo e(asset('assets/js/vendor/isotop.js')); ?>"></script>
 <script src="<?php echo e(asset('assets/js/vendor/imageloaded.js')); ?>"></script>

 <script src="<?php echo e(asset('assets/js/vendor/wow.js')); ?>"></script>
 <script src="<?php echo e(asset('assets/js/vendor/waypoint.min.js')); ?>"></script>
 <script src="<?php echo e(asset('assets/js/vendor/easypie.js')); ?>"></script>
 <script src="<?php echo e(asset('assets/js/vendor/text-type.js')); ?>"></script>
 <script src="<?php echo e(asset('assets/js/vendor/jquery-one-page-nav.js')); ?>"></script>
 <script src="<?php echo e(asset('assets/js/vendor/bootstrap-select.min.js')); ?>"></script>
 <script src="<?php echo e(asset('assets/js/vendor/jquery-ui.js')); ?>"></script>
 <script src="<?php echo e(asset('assets/js/vendor/magnify-popup.min.js')); ?>"></script>
 <script src="<?php echo e(asset('assets/js/vendor/paralax-scroll.js')); ?>"></script>
 <script src="<?php echo e(asset('assets/js/vendor/paralax.min.js')); ?>"></script>
 <script src="<?php echo e(asset('assets/js/vendor/countdown.js')); ?>"></script>
 <script src="<?php echo e(asset('assets/js/vendor/plyr.js')); ?>"></script>
 <!-- Main JS -->
 <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
 <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

<?php /**PATH C:\Users\koneb\Desktop\abclub\resources\views/users/layouts/js.blade.php ENDPATH**/ ?>