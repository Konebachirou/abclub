<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make('users.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body class="rbt-header-sticky">
    <?php echo $__env->make('users.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- <main class="rbt-main-wrapper"> -->
    <?php echo $__env->yieldContent('content'); ?>
    <!-- </main> -->
    <?php echo $__env->make('users.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('users.layouts.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH C:\Users\koneb\Desktop\abclub\resources\views/users/layouts/app.blade.php ENDPATH**/ ?>