
<?php $__env->startSection('titre', 'ABC Connect - African Business Club'); ?>
<?php $__env->startSection('content'); ?>

<div class="rbt-service-area bg-color-white rbt-section-gap">
    <div class="container">
        <div class="row mb--60">
            <div class="col-lg-12">
                <div class="section-title text-center">
                    <span class="subtitle bg-secondary-opacity">Exam Preparation</span>
                    <h2 class="title">Annual Exam Preparation</h2>
                </div>
            </div>
        </div>
        <div class="row row--15 mt_dec--30">

            <!-- Start Single Card  -->
            <div class="col-xl-6 col-md-6 col-sm-6 col-12 mt--30">
                <div class="rbt-service rbt-service-2 variation-2 rbt-hover-02">
                    <div class="inner">
                        <div class="content">
                            <h4 class="title"><a href="#">BCS Exam</a></h4>
                            <p>Lorem ipsum dolor sit, amet consectetur.</p>
                            <div class="row">
                                <div class="col-lg-6">
                                    <ul class="rbt-list-style-3">
                                        <li><i class="feather-youtube"></i> 125 Free Video</li>
                                        <li><i class="feather-book"></i> 12 Subjects</li>
                                    </ul>
                                </div>
                            </div>
                            
                        </div>
                        <div class="thumbnail">
                            <img src="assets/images/others/service-01.png" alt="Education Images">
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Single Card  -->

            <!-- Start Single Card  -->
            <div class="col-xl-6 col-md-6 col-sm-6 col-12 mt--30">
            <div class="row row--0 about-wrapper align-items-center theme-shape"  style="padding: 0px !important;">
                        <div class="col-lg-7">
                            <div class="thumbnail">
                                <img src="assets/images/others/expe.png" alt="About Images">
                            </div>
                        </div>
                        <div class="col-lg-5 mt_md--30 mt_sm--30" >
                            <div class="content">
                                <div class="inner text-center">
                                <h5 class="title">Retour d’expériences (Africarrières)</h5>
                                </div>
                            </div>
                        </div>
                        <div class="top-circle-shape position-bottom-right"></div>
                    </div>
              
            </div>
            <!-- End Single Card  -->

            <!-- Start Single Card  -->
            <div class="col-xl-6 col-md-6 col-sm-6 col-12 mt--30">
                <div class="rbt-service rbt-service-2 variation-2 rbt-hover-02">
                    <div class="inner">
                       
                        <div class="thumbnail">
                            <img src="assets/images/others/expe.png" alt="Education Images">
                        </div>
                         <div class="content" style="padding-left: 18px;">
                            <h5 class="title">Retour d’expériences (Africarrières)</h5>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Single Card  -->

            <!-- Start Single Card  -->
            <div class="col-xl-6 col-md-6 col-sm-6 col-12 mt--30">
                <div class="rbt-service rbt-service-2 variation-2 rbt-hover-02">
                    <div class="inner">
                        <div class="content">
                            <h4 class="title"><a href="#">IELTS Exam</a></h4>
                            <p>Lorem ipsum dolor sit, amet consectetur.</p>
                            <div class="row">
                                <div class="col-lg-6">
                                    <ul class="rbt-list-style-3">
                                        <li><i class="feather-youtube"></i> 150 Free Video</li>
                                        <li><i class="feather-book"></i> 26 Subjects</li>
                                    </ul>
                                </div>
                            </div>
                            
                        </div>
                        <div class="thumbnail">
                            <img src="assets/images/others/service-03.png" alt="Education Images">
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Single Card  -->
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('users.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\koneb\Desktop\abclub\resources\views/users/global/connect.blade.php ENDPATH**/ ?>