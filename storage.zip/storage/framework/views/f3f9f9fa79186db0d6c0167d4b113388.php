<?php $__env->startSection('titre', 'Nos Actions - African Business Club'); ?>

<?php $__env->startSection('content'); ?>

<!-- Start breadcrumb Area -->
<div class="rbt-breadcrumb-default ptb--100 ptb_md--50 ptb_sm--30 bg-gradient-1">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcrumb-inner text-center">
                    <h2 class="title">Nos Actions</h2>
                    <ul class="page-list">
                        <li class="rbt-breadcrumb-item"><a href="<?php echo e(route('home_link')); ?>">Accueil</a></li>
                        <li>
                            <div class="icon-right"><i class="feather-chevron-right"></i></div>
                        </li>
                        <li class="rbt-breadcrumb-item active">Nos Actions</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Breadcrumb Area -->

<?php $__currentLoopData = $actions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $action): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="rbt-about-area bg-color-white " id="about" style="margin-top: 3%;">
    <div class="container">
        <div class="row g-5 align-items-center">
            <div class="col-lg-6 order-2 order-lg-1">
                <div class="inner">
                    <div class="section-title text-start">
                        <h2 class="title"><?php echo e($action->title); ?></h2>
                        <div class="description mt--30" style="display: -webkit-box;
        -webkit-line-clamp: 5;
        -webkit-box-orient: vertical;
        overflow: hidden;"><?php echo $action->description; ?></div>
                        <div class="read-more-btn mt-3">
                            <a class="rbt-moderbt-btn" href="<?php echo e(route('news_details_link', $action->title)); ?>">
                                <span class="moderbt-btn-text">Lire Plus</span>
                                <i class="feather-arrow-right"></i>
                            </a> 
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 order-1 order-lg-2">
                <div class="content">
                    <a href="<?php echo e(route('news_details_link', $action->title)); ?>">
                        <img class="w-100 rbt-radius" src="<?php echo e($action->illustrationUrl()); ?>" alt="<?php echo e($action->title); ?>">
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('users.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\koneb\Desktop\abclub\resources\views/users/global/action.blade.php ENDPATH**/ ?>